package ab.demo;

import ab.vision.ABObject;
import java.lang.reflect.Array;
import java.util.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.List;
import ab.demo.other.ActionRobot;
import ab.vision.ABType;
import ab.vision.Vision;
import java.awt.geom.Line2D;
import java.awt.Rectangle;
/**
 * Created by admin on 10/29/2014.
 */
public class Heuristic {
    BufferedImage screenshot = ActionRobot.doScreenShot();
    Vision vision = new Vision(screenshot);

    public Point target_pt()
    {
        List<ABObject> birds=vision.findBirdsMBR();
        List<ABObject> blocks=vision.findBlocksMBR();
        List<ABObject> pigs=vision.findPigsMBR();
        List<ABObject> tnts=vision.findTNTs();
       // List<ABObject> hills=vis ion.findHills();
        int i=0;
        Point pt=new Point(0,0);
        for(ABObject p:pigs)
        {
            System.out.println("-------in "+i+" points "+p.getLocation()+" -------------" );
        }
        return pt;
    }

}
